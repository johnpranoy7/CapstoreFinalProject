package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Query_Master;
import com.cg.service.QueryService;




@Controller
public class QueryController {
	ArrayList<String> plans;
	
	@Autowired
	QueryService queryService;  
	
	@RequestMapping("/index")
	public String getHomePage(Model model) {
		model.addAttribute("queryMaster",new Query_Master());
		return "index";
	}
	
	@RequestMapping("/gettingId")
	public String selection(Model model,@RequestParam("queryId") String queryId)
	{	Query_Master query_Master = queryService.getTransaction(Integer.parseInt(queryId));
		model.addAttribute("qId",Integer.parseInt(queryId));
		model.addAttribute("query_Master",query_Master);
		model.addAttribute("SMEs",new String[]{"Uma","Rahul","Kavitha","Hema"});
		if(query_Master!=null)
			return "editPage";
		else
			return "errorPage";
	}
	
	@RequestMapping("/update")
	public String update(@ModelAttribute("query_Master")Query_Master query_Master,Model model )
	{
		queryService.update(query_Master);
		model.addAttribute("qId",query_Master.getQuery_Id());
		return "success";
	}
}
