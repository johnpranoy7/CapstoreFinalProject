package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Query_Master;

@Repository
public class QueryRepositryImpl implements QueryRepositry {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public Query_Master save(Query_Master query_Master) {
		entityManager.persist(query_Master);
		entityManager.flush();
		return query_Master;
	}

	@Override
	public List<Query_Master> showTransactions() {
		TypedQuery<Query_Master> query=entityManager.createQuery("select q from Query_Master q",Query_Master.class);
		return query.getResultList();
	}

	@Override
	public Query_Master getTransaction(int query_Master) {
		
		Query_Master master= entityManager.find(Query_Master.class, query_Master);
		return master;
		

	}

	@Override
	public void update(Query_Master query_Master) {
		Query_Master query_Master1 = entityManager.find(Query_Master.class,query_Master.getQuery_Id());
		query_Master1.setSolutions(query_Master.getSolutions());
	}

}
