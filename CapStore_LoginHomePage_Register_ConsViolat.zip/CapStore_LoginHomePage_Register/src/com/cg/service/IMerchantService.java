package com.cg.service;

import com.cg.entities.Merchant;

public interface IMerchantService {
	Merchant isMerchant(String userName, String userPassword);
	String getMerchantPassword(String userName);
}
