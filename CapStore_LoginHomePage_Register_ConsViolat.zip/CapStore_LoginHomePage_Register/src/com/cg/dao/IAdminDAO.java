package com.cg.dao;

import com.cg.entities.Admin;

public interface IAdminDAO {

	Admin isAdmin(String userName, String userPassword);
	String getAdminPassword(String userName);

}
