package com.cg.controller;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entities.Customer;
import com.cg.service.ICustomerService;

@Controller
public class CustomerController {

	@Autowired
	ICustomerService customerService;
	
	
	/*@RequestMapping("/index")
	public String indexPage(Model model) {
		model.addAttribute("customerName",customerService.showSessions().getCustomerName());
		return "customerPage";
	}*/
	
	
	@RequestMapping("/customerProfile")
	public String myProfile(Model model,String customerId,HttpSession session) {
		int id=(int)session.getAttribute("userId");
		model.addAttribute("Customer",customerService.showSessions(id));
		return "myProfile";
		
	}
	
	
	@RequestMapping("/update")
	public String updateProfile(Model model,Customer customer) {
		customerService.updateProfile(customer);
		model.addAttribute("Customer", new Customer());
		return "success";
	}
	
	@RequestMapping("/wishlist")
	public String wishList(Model model) {
		return "wishlist";
	}
	
	
	@RequestMapping("/deliveryStatus")
	public String deliveryStatus(Model model) {
		return "deliverystatus";
	}
	
	
	@RequestMapping("/ordereditems")
	public String orderedItems(Model model) {
		return "ordereditems";
	}
}
