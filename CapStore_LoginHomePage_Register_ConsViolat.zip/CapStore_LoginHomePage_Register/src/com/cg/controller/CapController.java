package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.QueryException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Customer;
import com.cg.entities.Merchant;
import com.cg.service.IAdminService;
import com.cg.service.ICustomerService;
import com.cg.service.IMerchantService;
import com.cg.service.IQueryService;

@Controller
public class CapController {
	
	@Autowired
	IQueryService iQueryService;
	@Autowired
	IAdminService iAdminService;
	@Autowired
	IMerchantService iMerchantService;
	@Autowired
	ICustomerService iCustomerService;
	
	
	@RequestMapping("/index")			
	public String index() {
		iQueryService.plp();
		return "index";					// To AJAYS HomePAge
	}
	
	@RequestMapping("/loginpage")
	public String loginindex() {
		return "loginpage";
	}
	
	@RequestMapping("/decidor")
	public String decidor(Model model,@RequestParam("emailId")String emailId, @RequestParam("pass")String password,HttpSession session)
	{	
		System.out.println("Is Admin"+iAdminService.isAdmin(emailId,password));
		System.out.println("Is Merchant"+iMerchantService.isMerchant(emailId, password));
		System.out.println("Is Customer"+iCustomerService.isCustomer(emailId, password));
		
		if(iAdminService.isAdmin(emailId, password)!=null)
		{
			model.addAttribute("details",iAdminService.isAdmin(emailId, password));
			session.setAttribute("userId",iAdminService.isAdmin(emailId, password).getAdminId());
			session.setAttribute("user", "admin");
			return "adminPage";
		}
		else if(iMerchantService.isMerchant(emailId, password)!=null)
		{
			model.addAttribute("details",iMerchantService.isMerchant(emailId, password));
			session.setAttribute("userId",iMerchantService.isMerchant(emailId, password).getMerchantId());
			session.setAttribute("user", "merchant");
			return "merchantPage";
		}
		else if(iCustomerService.isCustomer(emailId, password)!=null)
		{
			model.addAttribute("details",iCustomerService.isCustomer(emailId, password));
			session.setAttribute("userId",iCustomerService.isCustomer(emailId, password).getCustomerId());
			session.setAttribute("user", "customer");
			model.addAttribute("customerName",iCustomerService.isCustomer(emailId, password).getCustomerName());
			return "customerPage";
		}
		else
			return "loginpage";
		/*return "decidor";*/
	}
	
	 @RequestMapping("/CustomerRegister")
	public String register(Model model)
	{
		model.addAttribute("customer",new Customer());
		return "CustomerRegister";
	}
	@RequestMapping(value="/customersave")
	public String save(@ModelAttribute("customer")@Valid Customer customers,BindingResult result,Model model ) {
		if(result.hasErrors()) {
		return "CustomerRegister";
		}
		else {
		//customers.setPassword(encryptPassword(customers.getPassword()));
		//System.out.println(customers.getPassword());
		customers=iQueryService.saveCustomer(customers);
		model.addAttribute("message","Registration id is "+customers.getCustomerId()+"\n transaction done successful");
		return "redirect:/index.html";
		}
//------------//for Merchant Registration-----------------------------
	}
	@RequestMapping("/MerchantRegister")
	public String merchantRegister(Model model)
	{
		model.addAttribute("merchant", new Merchant());
		return "MerchantRegister";
	}
	
	@RequestMapping(value="/merchantsave")
	public String save1(@ModelAttribute("merchant")@Valid Merchant merchant,BindingResult result,Model model ) {
		if(result.hasErrors()) {
		return "MerchantRegister";
		}
		else {
		//merchant.setPassword(encryptPassword(merchant.getPassword()));
		//System.out.println(merchant.getPassword());
		merchant=iQueryService.saveMerchant(merchant);
		model.addAttribute("message","Registration id is "+merchant.getMerchantId()+"\n transaction done successful");
		return "redirect:/index.html";
		}
	}
	
	@RequestMapping("/homepage")
	public String loginsession() {	
		return "homepage";
	}
	
	@RequestMapping("/forgotPwd")
	public String forgotPassword() {
		return "forgotPassword";
	}
	
	@RequestMapping("/retrievePassword")
	public String retrievePassword(Model model,@RequestParam("emailId")String emailId) {
		String password=null;
		if(iAdminService.getAdminPassword(emailId)!=null)
			password=iAdminService.getAdminPassword(emailId);
		else if(iCustomerService.getCustomerPassword(emailId)!=null)
			password=iCustomerService.getCustomerPassword(emailId);
		else if(iMerchantService.getMerchantPassword(emailId)!=null)
			password=iMerchantService.getMerchantPassword(emailId);
		model.addAttribute("password", password);
		System.out.println(password);
		return "forgotPassword";
	}
	
	
	/*public String encryptPassword(String password) {
		StringBuffer encryptPassword=new StringBuffer();
		int id=1;
		for(int i=0;i<password.length();i++) {
			int ascii=(int)password.charAt(i)+id*i;
			String j=Character.toString((char)ascii);
			encryptPassword.append(j);
		}
		return encryptPassword.toString();
	}*/
	
}
