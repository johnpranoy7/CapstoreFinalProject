package com.cg.entities;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Merchant implements Serializable{
	@Id
	@GeneratedValue
	private int merchantId;
	//@NotEmpty(message="please enter valid email")
	@Pattern(regexp ="^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$",message="enter valid email")
	private String emailId;
	//@NotEmpty(message="Please enter your password")
	@Size(min=5,max=10,message="password should be between 5 to 10")
	@Pattern(regexp ="^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{5,10}$",message="enter password with captial letters,small letters,numbers")
	private String password;
	@NotEmpty(message="name is mandatory")
	private String merchantName;
	private String address;
	private Double rating;
	private Double money;
	private int noOfRatings;
	
	public int getNoOfRatings() {
		return noOfRatings;
	}
	public void setNoOfRatings(int noOfRatings) {
		this.noOfRatings = noOfRatings;
	}
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Double getRating() {
		return rating;
	}
	public void setRating(Double rating) {
		this.rating = rating;
	}
	public Double getMoney() {
		return money;
	}
	public void setMoney(Double money) {
		this.money = money;
	}
	public Merchant( String emailId, String password, String merchantName, String address, Double rating,
			Double money) {
		super();
		this.emailId = emailId;
		this.password = password;
		this.merchantName = merchantName;
		this.address = address;
		this.rating = rating;
		this.money = money;
	}
	public Merchant() {
		super();
	}
	@Override
	public String toString() {
		return "Merchant [merchantId=" + merchantId + ", emailId=" + emailId + ", password=" + password
				+ ", merchantName=" + merchantName + ", address=" + address + ", rating=" + rating + ", money=" + money
				+ ", noOfRatings=" + noOfRatings + "]";
	}
	
	
}
