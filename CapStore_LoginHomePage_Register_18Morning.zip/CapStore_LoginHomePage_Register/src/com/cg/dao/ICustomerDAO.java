package com.cg.dao;

import java.util.List;

import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.SoldItems;

public interface ICustomerDAO {

	Customer isCustomer(String userName, String userPassword);
	String getCustomerPassword(String userName);
	
	public 	Inventory checkOrderedItems();
	public Inventory checkWishList();
	public void updateProfile(Customer customer);
	public Customer find(int customerId);
	public Customer showSessions(int id);
	Customer changePassword(Customer customer);
	int getIdFromEmail(String emailId);
	List<Inventory> getWishList(int customerId);
	
	void saveToCart(int inventoryId, int customerId);
	void saveToWishList(int inventoryId, int customerId);
	List<SoldItems> getOrderedItems(int customerId);

}
