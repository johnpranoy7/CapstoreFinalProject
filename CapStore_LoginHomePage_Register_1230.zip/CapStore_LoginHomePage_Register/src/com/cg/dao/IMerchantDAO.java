package com.cg.dao;

import com.cg.entities.Merchant;

public interface IMerchantDAO {

		Merchant isMerchant(String userName, String userPassword);
		String getMerchantPassword(String userName);

}
