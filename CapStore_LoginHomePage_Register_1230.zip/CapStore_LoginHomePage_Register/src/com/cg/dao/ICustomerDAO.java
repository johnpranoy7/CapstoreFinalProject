package com.cg.dao;

import com.cg.entities.Customer;
import com.cg.entities.Inventory;

public interface ICustomerDAO {

	Customer isCustomer(String userName, String userPassword);
	String getCustomerPassword(String userName);
	
	public 	Inventory checkOrderedItems();
	public Inventory checkWishList();
	public void updateProfile(Customer customer);
	public Customer find(int customerId);
	public Customer showSessions(int id);
	Customer changePassword(Customer customer);
	int getIdFromEmail(String emailId);

}
