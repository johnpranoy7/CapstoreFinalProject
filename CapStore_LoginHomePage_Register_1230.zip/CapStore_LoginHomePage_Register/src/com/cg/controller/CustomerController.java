package com.cg.controller;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Customer;
import com.cg.service.ICustomerService;

@Controller
public class CustomerController {

	@Autowired
	ICustomerService customerService;
	
	
	/*@RequestMapping("/index")
	public String indexPage(Model model) {
		model.addAttribute("customerName",customerService.showSessions().getCustomerName());
		return "customerPage";
	}*/
	
	
	@RequestMapping("/customerProfile")
	public String myProfile(Model model,String customerId,HttpSession session) {
		String emailId=(String) session.getAttribute("userEmailId");
		int custId=(int) session.getAttribute("custId");
		model.addAttribute("Customer",customerService.showSessions(custId));
		return "myProfile";
		
	}
	
	@RequestMapping("/changeCustomerPassword")
	public String changeCustomerPassword(Model model,String customerId,HttpSession session)
	{
		String userId=(String) session.getAttribute("userEmailId");
		int custId=(int) session.getAttribute("custId");
		Customer customer=customerService.find(custId);
		return "changeCustomerPassword";
		
	}
	
	@RequestMapping("/changePwdImpl.html")
	public String changeCustomerPwdImpl(Model model,@RequestParam("oldPwd")String oldPwd,@RequestParam("newPwd")String newPwd,@RequestParam("newPwd1")String newPwd1,String customerId,HttpSession session)
	{
		String userId=(String) session.getAttribute("userEmailId");
		int custId=(int) session.getAttribute("custId");
		Customer customer=customerService.find(custId);
		String eOldPwd=encryptPassword(oldPwd);//encrypt old password
		String eNewPwd=encryptPassword(newPwd);
		String eNewPwd1=encryptPassword(newPwd1);
		System.out.println("ChangePWD IMPL CHK:"+userId+" "+custId+" "+eOldPwd);
		System.out.println(" "+eNewPwd); 
		boolean validate=(customer.getPassword()).equals(eOldPwd); //this is coming false check this
		boolean x=eNewPwd.equals(eNewPwd1);
		System.out.println("validate"+validate+"/nx:"+x);
		if(validate==true && eNewPwd.equals(eNewPwd1))
		{
			customer.setPassword(eNewPwd1);
			customerService.changePassword(customer);
			model.addAttribute("message","PasswordChanged");
			System.out.println(customer);
			return "customerPage";
		}
		return "changeCustomerPassword";
		
	}
	@RequestMapping("/update")
	public String updateProfile(Model model,Customer customer) {
		customerService.updateProfile(customer);
		model.addAttribute("Customer", new Customer());
		return "success";
	}
	
	@RequestMapping("/wishlist")
	public String wishList(Model model) {
		return "wishlist";
	}
	
	
	@RequestMapping("/deliveryStatus")
	public String deliveryStatus(Model model) {
		return "deliverystatus";
	}
	
	
	@RequestMapping("/ordereditems")
	public String orderedItems(Model model) {
		return "ordereditems";
	}
	
	public String encryptPassword(String password) {
		StringBuffer encryptPassword=new StringBuffer();
		int id=1;
		for(int i=0;i<password.length();i++) {
			int ascii=(int)password.charAt(i)+id*i;
			String j=Character.toString((char)ascii);
			encryptPassword.append(j);
		}
		return encryptPassword.toString();
	}
}
