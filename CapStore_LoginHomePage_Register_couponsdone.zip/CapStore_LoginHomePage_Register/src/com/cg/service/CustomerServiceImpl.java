package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ICustomerDAO;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.SoldItems;


@Service
@Transactional
public class CustomerServiceImpl implements ICustomerService {
	
	@Autowired
	ICustomerDAO iCustomerDAO;
	@Override
	public Customer isCustomer(String userName, String userPassword) {
		return iCustomerDAO.isCustomer(userName,userPassword);
	}
	@Override
	public String getCustomerPassword(String userName) {
		// TODO Auto-generated method stub
		return iCustomerDAO.getCustomerPassword(userName);
	}
	
	@Override
	public Inventory checkOrderedItems() {
		// TODO Auto-generated method stub
		return iCustomerDAO.checkOrderedItems();
	}

	@Override
	public Inventory checkWishList() {
		// TODO Auto-generated method stub
		return iCustomerDAO.checkWishList();
	}

	@Override
	public void updateProfile(Customer customer) {
		// TODO Auto-generated method stub
		 iCustomerDAO.updateProfile(customer);
	}

	@Override
	public Customer find(int customerId) {
		// TODO Auto-generated method stub
		return iCustomerDAO.find(customerId);
	}

	@Override
	public Customer showSessions(int id) {
		// TODO Auto-generated method stub
		return iCustomerDAO.showSessions(id);
	}
	@Override
	public Customer changePassword(Customer customer) {
		// TODO Auto-generated method stub
		return iCustomerDAO.changePassword(customer);
	}
	@Override
	public int getIdFromEmail(String emailId) {
		// TODO Auto-generated method stub
		return iCustomerDAO.getIdFromEmail(emailId);
	}
	@Override
	public List<Inventory> getWishList(int customerId) {
		// TODO Auto-generated method stub
		return iCustomerDAO.getWishList(customerId);
	}
	
	@Override
	public void saveToCart(int inventoryId, int customerId) {
		// TODO Auto-generated method stub
		iCustomerDAO.saveToCart(inventoryId,customerId);
	}
	@Override
	public void saveToWishList(int inventoryId, int customerId) {
		// TODO Auto-generated method stub
	iCustomerDAO.saveToWishList(inventoryId,customerId);	
	}
	@Override
	public List<SoldItems> getOrderedItems(int customerId) {
		// TODO Auto-generated method stub
		return iCustomerDAO.getOrderedItems(customerId);
	}
	@Override
	public void setFeedback(int parseInt, String feedback) {
		iCustomerDAO.setFeedback(parseInt,feedback);
		
	}
	@Override
	public void setCoupon(int id, String coupon, String discount) {
		// TODO Auto-generated method stub
		iCustomerDAO.setCoupon(id,coupon,Integer.parseInt(discount));
	}

}
