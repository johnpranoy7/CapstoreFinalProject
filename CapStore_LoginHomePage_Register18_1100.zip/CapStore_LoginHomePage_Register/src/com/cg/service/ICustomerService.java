package com.cg.service;

import java.util.List;

import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.SoldItems;

public interface ICustomerService {
	Customer isCustomer(String userName, String userPassword);
	String getCustomerPassword(String userName);
	
	public  Inventory checkOrderedItems();
	 public Inventory  checkWishList();
    public void updateProfile(Customer customer);
	public Customer find(int customerId);
	public Customer showSessions(int id);
	public Customer changePassword(Customer customer);
	public int getIdFromEmail(String emailId);
	List<Inventory> getWishList(int customerId);
	
	
	void saveToCart(int parseInt, int customerId);
	void saveToWishList(int parseInt, int customerId);
	List<SoldItems> getOrderedItems(int customerId);
	void setFeedback(int parseInt, String feedback);
}
