package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ICustomerDAO;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;


@Service
@Transactional
public class CustomerServiceImpl implements ICustomerService {
	
	@Autowired
	ICustomerDAO iCustomerDAO;
	@Override
	public Customer isCustomer(String userName, String userPassword) {
		return iCustomerDAO.isCustomer(userName,userPassword);
	}
	@Override
	public String getCustomerPassword(String userName) {
		// TODO Auto-generated method stub
		return iCustomerDAO.getCustomerPassword(userName);
	}
	
	@Override
	public Inventory checkOrderedItems() {
		// TODO Auto-generated method stub
		return iCustomerDAO.checkOrderedItems();
	}

	@Override
	public Inventory checkWishList() {
		// TODO Auto-generated method stub
		return iCustomerDAO.checkWishList();
	}

	@Override
	public void updateProfile(Customer customer) {
		// TODO Auto-generated method stub
		 iCustomerDAO.updateProfile(customer);
	}

	@Override
	public Customer find(int customerId) {
		// TODO Auto-generated method stub
		return iCustomerDAO.find(customerId);
	}

	@Override
	public Customer showSessions(int id) {
		// TODO Auto-generated method stub
		return iCustomerDAO.showSessions(id);
	}
	@Override
	public Customer changePassword(Customer customer) {
		// TODO Auto-generated method stub
		return iCustomerDAO.changePassword(customer);
	}
	@Override
	public int getIdFromEmail(String emailId) {
		// TODO Auto-generated method stub
		return iCustomerDAO.getIdFromEmail(emailId);
	}

}
