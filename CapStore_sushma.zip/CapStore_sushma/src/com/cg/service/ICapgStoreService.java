package com.cg.service;

import java.util.List;

import com.cg.entities.Customer;
import com.cg.entities.Merchant;

public interface ICapgStoreService {

	// List<QueryAnswers> getall();


public Customer save(Customer customer);

public Merchant save1(Merchant merchant);
}
