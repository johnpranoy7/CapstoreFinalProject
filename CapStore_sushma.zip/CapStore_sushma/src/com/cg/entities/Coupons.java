package com.cg.entities;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Coupons implements Serializable{

	@Id
	@GeneratedValue
	int couponId;
	String couponNumber;
	Date expiryDate;
	Double discount;
	public int getCouponId() {
		return couponId;
	}
	public void setCouponId(int couponId) {
		this.couponId = couponId;
	}
	public String getCouponNumber() {
		return couponNumber;
	}
	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	public Double getDiscount() {
		return discount;
	}
	public void setDiscount(Double discount) {
		this.discount = discount;
	}
	public Coupons(int couponId, String couponNumber, Date expiryDate, Double discount) {
		super();
		this.couponId = couponId;
		this.couponNumber = couponNumber;
		this.expiryDate = expiryDate;
		this.discount = discount;
	}
	public Coupons() {
		super();
	}
	
	
}
