package com.cg.dao;

import com.cg.entities.Customer;
import com.cg.entities.Merchant;

public interface ICapgstoreDAO {
	
	
	public Customer save(Customer customer);
	
	public Merchant save1(Merchant merchant);
}
