package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;

@Repository
public class CapgstoreDAOImpl implements ICapgstoreDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	

	@Override
	public Customer save(Customer customer) {
		Admin admin=new Admin("griet", "griet@gmail.com", "asdd", 20.0);
	    /* Customer customer1=new Customer("dfjhb@gmail.com", "ddfdf", "fead", "fewre", 1540.45);
	     Merchant merchant=new Merchant("afefq", "qer", "eefewf", "efqf", 1.00, 200.0);
	     Inventory inventory=new Inventory("qqede", 50, 200.00, "edeq", 0.00, 0.00);
	     inventory.setMerchant(merchant);*/
	     //customer.setCart(inventory);
	     //customer.setWishList(inventory);
	    /* entityManager.persist(admin);
	     entityManager.persist(merchant);
	     entityManager.persist(inventory);*/
	     entityManager.persist(customer);
	     entityManager.flush();
		return customer;
		
	}



	@Override
	public Merchant save1(Merchant merchant) {
		entityManager.persist(merchant);
		entityManager.flush();
		return merchant;
	}



	

	
}
