package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.hibernate.QueryException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Customer;
import com.cg.entities.Merchant;
import com.cg.service.ICapgStoreService;

@Controller
public class CapgStoreController {
	
	@Autowired
	ICapgStoreService capgStoreService;
	//------------to get the index page------------------
	@RequestMapping("/index")
	public String index() {
		
		return "index";
	}
//-------------//for Customer registration----------------------
	@RequestMapping("/register")
	public String register(Model model)
	{
		model.addAttribute("customer",new Customer());
		return "register";
	}
	@RequestMapping(value="/save")
	public String save(@ModelAttribute("customer")@Valid Customer customers,BindingResult result,Model model ) {
		if(result.hasErrors()) {
		return "register";
		}
		else {
		customers=capgStoreService.save(customers);
		model.addAttribute("message","Registration id is "+customers.getCustomerId()+"\n transaction done successful");
		return "redirect:/index.html";
		}
//------------//for Merchant Registration-----------------------------
	}
	@RequestMapping("/MerchantRegister")
	public String merchantRegister(Model model)
	{
		model.addAttribute("merchant", new Merchant());
		return "MerchantRegister";
	}
	
	@RequestMapping(value="/merchantsave")
	public String save1(@ModelAttribute("merchant")@Valid Merchant merchant,BindingResult result,Model model ) {
		if(result.hasErrors()) {
		
		return "MerchantRegister";
		}
		else {
		merchant=capgStoreService.save1(merchant);
		model.addAttribute("message","Registration id is "+merchant.getMerchantId()+"\n transaction done successful");
		return "redirect:/index.html";
		}
	}
	
}
