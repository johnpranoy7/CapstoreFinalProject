package com.cg.dao;

import com.cg.entities.Customer;

public interface ICustomerDAO {

	Customer isCustomer(String userName, String userPassword);

}
