package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;

@Repository
public class AdminDAOImpl implements IAdminDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
		public Admin isAdmin(String userName, String userPassword) {
		TypedQuery<Admin> query=entityManager.createQuery("select a from Admin a where a.emailId=:eId and a.password=:pwd",Admin.class);
		query.setParameter("eId",userName);
		query.setParameter("pwd",userPassword);
		List<Admin> users = query.getResultList();
		//System.out.println(users);
		if(users.size()>0)
			return users.get(0);
		else
			return null; 
		//Check from Admin table if username and password are present in it
		/* 
		TypedQuery<Query_Master> query=entityManager.createQuery("select q from Query_Master q",Query_Master.class);
		return query.getResultList();
		
		String sql="from Customer lgn where lgn.emailId=:uName and lgn.custPassword=:uPwd";
		Query query= manager.createQuery(sql);
		query.setParameter("uName", loginPojo.getEmailId());
		query.setParameter("uPwd", loginPojo.getCustPassword());
		List<Customer> logins= query.getResultList();

		*/
	}

}
