package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Customer;

@Repository
public class CustomerDAOImpl implements ICustomerDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public Customer isCustomer(String userName, String userPassword) {
		// Check from DB if it is available in the db
		TypedQuery<Customer> query=entityManager.createQuery("select c from Customer c where c.emailId=:eId and c.password=:pwd",Customer.class);
		query.setParameter("eId",userName);
		query.setParameter("pwd",userPassword);
		List<Customer> users = query.getResultList();
		//System.out.println(users);
		if(users.size()>0)
			return users.get(0);
		else
			return null; 
	}

}
