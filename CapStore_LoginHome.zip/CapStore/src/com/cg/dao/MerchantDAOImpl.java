package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Merchant;

@Repository
public class MerchantDAOImpl implements IMerchantDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public Merchant isMerchant(String userName, String userPassword) {
		
		TypedQuery<Merchant> query=entityManager.createQuery("select a from Merchant a where a.emailId=:eId and a.password=:pwd",Merchant.class);
		query.setParameter("eId",userName);
		query.setParameter("pwd",userPassword);
		List<Merchant> users = query.getResultList();
		//System.out.println(users);
		if(users.size()>0)
			return users.get(0);
		else
			return null; 
		 
	}

}
