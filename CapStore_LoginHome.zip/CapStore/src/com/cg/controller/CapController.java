package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.QueryException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.service.IAdminService;
import com.cg.service.ICustomerService;
import com.cg.service.IMerchantService;
import com.cg.service.IQueryService;

@Controller
public class CapController {
	
	@Autowired
	IQueryService iQueryService;
	@Autowired
	IAdminService iAdminService;
	@Autowired
	IMerchantService iMerchantService;
	@Autowired
	ICustomerService iCustomerService;
	
	
	@RequestMapping("/index")			
	public String index() {
		//iQueryService.plp();
		return "index";					// To AJAYS HomePAge
	}
	
	@RequestMapping("/loginpage")
	public String loginindex() {
		return "loginpage";
	}
	
	@RequestMapping("/decidor")
	public String decidor(Model model,@RequestParam("emailId")String emailId, @RequestParam("pass")String password)
	{	
		System.out.println("Is Admin"+iAdminService.isAdmin(emailId,password));
		System.out.println("Is Merchant"+iMerchantService.isMerchant(emailId, password));
		System.out.println("Is Customer"+iCustomerService.isCustomer(emailId, password));
		
		if(iAdminService.isAdmin(emailId, password)!=null)
		{
			model.addAttribute("details",iAdminService.isAdmin(emailId, password));
			return "adminPage";
		}
		else if(iMerchantService.isMerchant(emailId, password)!=null)
		{
			model.addAttribute("details",iMerchantService.isMerchant(emailId, password));
			return "merchantPage";
		}
		else if(iCustomerService.isCustomer(emailId, password)!=null)
		{
			model.addAttribute("details",iCustomerService.isCustomer(emailId, password));
			return "customerPage";
		}
		else
			return "loginpage";
		/*return "decidor";*/
	}
	
	@RequestMapping("/homepage")
	public String loginsession() {	
		return "homepage";
	}
	
	@RequestMapping("/forgotPwd")
	public String forgotPassword() {
		return "homepage";
	}
	
}
