package com.cg.service;

import com.cg.entities.Customer;

public interface ICustomerService {
	Customer isCustomer(String userName, String userPassword);
}
