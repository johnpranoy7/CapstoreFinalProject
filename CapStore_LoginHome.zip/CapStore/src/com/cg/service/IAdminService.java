package com.cg.service;

import com.cg.entities.Admin;

public interface IAdminService {
	Admin isAdmin(String userName, String userPassword);
}
