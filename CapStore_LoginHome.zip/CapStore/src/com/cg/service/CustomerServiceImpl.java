package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ICustomerDAO;
import com.cg.entities.Customer;


@Service
@Transactional
public class CustomerServiceImpl implements ICustomerService {
	
	@Autowired
	ICustomerDAO iCustomerDAO;
	@Override
	public Customer isCustomer(String userName, String userPassword) {
		return iCustomerDAO.isCustomer(userName,userPassword);
	}

}
