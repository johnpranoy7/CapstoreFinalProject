package com.cg.dao;

import com.cg.entities.SoldItems;

public interface IQueryDAO {
	
	void plp();
	void save(SoldItems soldItems);
}
