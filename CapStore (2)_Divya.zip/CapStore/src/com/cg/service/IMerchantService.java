package com.cg.service;

public interface IMerchantService {

}
