package com.cg.service;

public interface ICustomerService {

}
