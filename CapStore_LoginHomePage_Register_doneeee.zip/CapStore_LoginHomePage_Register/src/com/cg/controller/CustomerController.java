package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Coupons;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.service.ICustomerService;
import com.cg.service.IMerchantService;
import com.sun.javafx.sg.prism.NGShape.Mode;

@Controller
public class CustomerController {
	@Autowired
	HttpSession session;
	@Autowired
	ICustomerService customerService;
	
	@Autowired
	IMerchantService iMerchantService;
	@Autowired
	ICustomerService iCustomerService;
	/*@RequestMapping("/index")
	public String indexPage(Model model) {
		model.addAttribute("customerName",customerService.showSessions().getCustomerName());
		return "customerPage";
	}*/
	
	
	@RequestMapping("/customerProfile")
	public String myProfile(Model model,String customerId,HttpSession session) {
		String emailId=(String) session.getAttribute("userEmailId");
		int custId=(int) session.getAttribute("custId");
		model.addAttribute("Customer",customerService.showSessions(custId));
		return "myProfile";
		
	}
	
	@RequestMapping("/changeCustomerPassword")
	public String changeCustomerPassword(Model model,String customerId,HttpSession session)
	{
		String userId=(String) session.getAttribute("userEmailId");
		int custId=(int) session.getAttribute("custId");
		Customer customer=customerService.find(custId);
		return "changeCustomerPassword";
		
	}
	
	@RequestMapping("/changePwdImpl")
	public String changeCustomerPwdImpl(Model model,@RequestParam("oldPwd")String oldPwd,@RequestParam("newPwd")String newPwd,@RequestParam("newPwd1")String newPwd1,String customerId,HttpSession session)
	{
		String userId=(String) session.getAttribute("userEmailId");
		int custId=(int) session.getAttribute("custId");
		Customer customer=customerService.find(custId);
		String eOldPwd=encryptPassword(oldPwd);//encrypt old password
		String eNewPwd=encryptPassword(newPwd);
		String eNewPwd1=encryptPassword(newPwd1);
		System.out.println("ChangePWD IMPL CHK:"+userId+" "+custId+" "+eOldPwd);
		System.out.println(" "+eNewPwd); 
		boolean validate=(customer.getPassword()).equals(eOldPwd); //this is coming false check this
		boolean x=eNewPwd.equals(eNewPwd1);
		System.out.println("validate"+validate+"/nx:"+x);
		if(validate==true && eNewPwd.equals(eNewPwd1))
		{
			customer.setPassword(eNewPwd1);
			customerService.changePassword(customer);
			model.addAttribute("message","PasswordChanged");
			System.out.println(customer); 
			model.addAttribute("customerName",iCustomerService.isCustomer(customer.getEmailId(), eNewPwd).getCustomerName());
			model.addAttribute("inventory", iMerchantService.getAllInventory());
			model.addAttribute("passwordchange", "password changed successfully");
			return "customerPage";
		}
		return "changeCustomerPassword";
		
	}
	@RequestMapping("/updatepassword")
	public String updateProfile(Model model,Customer customer) {
		customerService.updateProfile(customer);
		model.addAttribute("Customer", new Customer());
		return "success";
	}
	@RequestMapping("/addToWishList")
	public String addToWishList(Model model,@RequestParam("itemId")String inventoryId) {
		int customerId=(int)session.getAttribute("userId");
		Customer customer=customerService.find(customerId);
		customerService.saveToWishList(Integer.parseInt(inventoryId),customerId);
		model.addAttribute("emailId",customer.getEmailId());
		String password=customer.getPassword();
		password=deencryptPassword(password);
		model.addAttribute("pass",password);
		model.addAttribute("messagewishlist", inventoryId+" added to wishlist");
		return "redirect:decidor.html";
	}
	
	@RequestMapping("/addToCartCust")
	public String addToCart(Model model,@RequestParam("itemId")String inventoryId)
	{
		int customerId=(int)session.getAttribute("userId");
		Customer customer=customerService.find(customerId);
		customerService.saveToCart(Integer.parseInt(inventoryId),customerId);
		model.addAttribute("emailId",customer.getEmailId());
		String password=customer.getPassword();
		password=deencryptPassword(password);
		model.addAttribute("pass",password);
		model.addAttribute("messagecart", inventoryId+" added to cart");
		return "redirect:decidor.html";
	}
	public String deencryptPassword(String password) {
		StringBuffer encryptPassword=new StringBuffer();
		int id=1;
		for(int i=0;i<password.length();i++) {
			int ascii=(int)password.charAt(i)-id*i;
			String j=Character.toString((char)ascii);
			encryptPassword.append(j);
		}
		return encryptPassword.toString();
	}
	@RequestMapping("/wishlist")
	public String wishList(Model model) {
		int customerId=(int)session.getAttribute("userId");
		List<Inventory> wishlist=customerService.getWishList(customerId);
		model.addAttribute("item", wishlist);
		model.addAttribute("sizeOfWishList", wishlist.size());
		System.out.println(wishlist.size());
		return "wishlist";
	}
	
	@RequestMapping("/wishtoadd")
	public String wishtoadd(@RequestParam("itemId")String inventoryId,Model model){
		int customerId=(int)session.getAttribute("userId");
		customerService.saveToCart(Integer.parseInt(inventoryId),customerId);
		model.addAttribute("message",inventoryId+"added to cart");
		return "redirect:wishlist.html";
	}
	
	@RequestMapping("/deliveryStatus")
	public String deliveryStatus(Model model) {
		return "deliverystatus";
	}
	
	
	@RequestMapping("/ordereditems")
	public String orderedItems(Model model) {
		int customerId=(int)session.getAttribute("userId");
		model.addAttribute("solditems", customerService.getOrderedItems(customerId));
		model.addAttribute("size", customerService.getOrderedItems(customerId).size());
		return "ordereditems";
	}
	
	@RequestMapping("/feedback")
	public String feedback(Model model,@RequestParam("id") String soldId)
	{
		model.addAttribute("id",soldId);
		return"feedbackForm";
	}
	@RequestMapping("/feedbackSubmitted")
	public String feedbackSubmitted(@RequestParam("id")String soldId,@RequestParam("feedback")String feedback)
	{
		customerService.setFeedback(Integer.parseInt(soldId),feedback);
		return "redirect:ordereditems.html";
	}
	
	public String encryptPassword(String password) {
		StringBuffer encryptPassword=new StringBuffer();
		int id=1;
		for(int i=0;i<password.length();i++) {
			int ascii=(int)password.charAt(i)+id*i;
			String j=Character.toString((char)ascii);
			encryptPassword.append(j);
		}
		return encryptPassword.toString();
	}
	
	@RequestMapping("/addCoupons")
	public String addCoupons(Model model) {
		
		return "addCoupons";
	}
	@RequestMapping("/setCoupon")
	public String setCoupon(Model model,@RequestParam("id")String id,@RequestParam("coupon")String coupon,@RequestParam("discount")String discount) {
		try {
			customerService.setCoupon(Integer.parseInt(id),coupon,discount);
		} catch (Exception e) {
			model.addAttribute("error","customer not present");
			return "addCoupons";
		}
		
		return "addCoupons";
	}
	@RequestMapping("/sorted")
	public String sorted(Model model ,@RequestParam("category")String id,@RequestParam("inventpe")String inventoryType) {
		System.out.println(id+" "+inventoryType);
		List<Inventory> inventories=new ArrayList<Inventory>();
		if(id.equals("1")) {
			inventories=customerService.inventoryLowToHigh(inventoryType);
		}
		else {
			inventories=customerService.inventoryHighToLow(inventoryType);
		}
		model.addAttribute("size", inventories.size());
		model.addAttribute("inventory",inventories);
		return "sorting";
	}
}
