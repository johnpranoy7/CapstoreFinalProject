package com.cg.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Coupons;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.SoldItems;

import oracle.net.aso.q;

@Repository
public class CustomerDAOImpl implements ICustomerDAO{

	@Autowired
	QueryDAOImpl queryDAOImpl;
	
	@PersistenceContext
	EntityManager entityManager;
	
	
	
	@Override
	public Customer isCustomer(String userName, String userPassword) {
		// Check from DB if it is available in the db
		System.out.println("DAO Ck:"+userName+" "+userPassword);
		TypedQuery<Customer> query=entityManager.createQuery("select c from Customer c where c.emailId=:eId and c.password=:pwd",Customer.class);
		query.setParameter("eId",userName);
		query.setParameter("pwd",userPassword);
		List<Customer> users = query.getResultList();
		//System.out.println(users);
		if(users.size()>0)
			return users.get(0);
		else
			return null; 
	}

	@Override
	public String getCustomerPassword(String userName) {
		TypedQuery<Customer> query=entityManager.createQuery("select c from Customer c where c.emailId=:eId",Customer.class);
		query.setParameter("eId",userName);
		List<Customer> users = query.getResultList();
		//System.out.println(users);
		if(users.size()>0) {
			return queryDAOImpl.decryptPassword(users.get(0).getPassword());
		}
		else
			return null; 
	}

	@Override
	public Inventory checkOrderedItems() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Inventory checkWishList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateProfile(Customer customer) {
		
		Customer updateCustomer=find(customer.getCustomerId());
		updateCustomer.setEmailId(customer.getEmailId());
		updateCustomer.setAddress(customer.getAddress());
		updateCustomer.setCustomerName(customer.getCustomerName());
		updateCustomer.setPassword(customer.getPassword());
		
	}

	@Override
	public Customer find(int customerId) {
		
		Customer customer=entityManager.find(Customer.class,customerId);
		return customer;
	}
	
	
	@Override
	public Customer showSessions(int id) {
		TypedQuery<Customer> query=entityManager.createQuery("select s from Customer s where customerId="+id,Customer.class);
    	return query.getSingleResult();
	}

	@Override
	public Customer changePassword(Customer customer) {
		entityManager.persist(customer);
		entityManager.flush();
		return customer;
	}

	@Override
	public int getIdFromEmail(String emailId) {
		TypedQuery<Customer> query=entityManager.createQuery("select s from Customer s where s.emailId=:eId",Customer.class);
		query.setParameter("eId",emailId);
		return query.getSingleResult().getCustomerId();
	}

	@Override
	public List<Inventory> getWishList(int customerId) {
		 Customer customer=entityManager.find(Customer.class, customerId);

			return customer.getWishList();
	}



	@Override
	public void saveToCart(int inventoryId, int customerId) {
		// TODO Auto-generated method stub
		Inventory inventory=entityManager.find(Inventory.class,inventoryId);
		 Customer customer=entityManager.find(Customer.class, customerId);
		 if(!customer.getCart().contains(inventory))
		 customer.setCart(inventory);
	}

	@Override
	public void saveToWishList(int inventoryId, int customerId) {
		// TODO Auto-generated method stub
		Inventory inventory=entityManager.find(Inventory.class,inventoryId);
		 Customer customer=entityManager.find(Customer.class, customerId);
		 if(!customer.getWishList().contains(inventory))
		 customer.setWishList(inventory);
	}

	@Override
	public List<SoldItems> getOrderedItems(int customerId) {
		TypedQuery<SoldItems> query=entityManager.createQuery("select s from SoldItems s where s.customer.customerId="+customerId,SoldItems.class);
		return query.getResultList();
	}

	@Override
	public void setFeedback(int parseInt, String feedback) {
		TypedQuery<SoldItems> query=entityManager.createQuery("select s from SoldItems s where s.soldItemId="+parseInt,SoldItems.class);
		SoldItems items=	query.getResultList().get(0);
		items.setFeedback(feedback);
	}

	@Override
	public void setCoupon(int id, String coupon, int discount) {
		// TODO Auto-generated method stub
		TypedQuery<Customer> query=entityManager.createQuery("select s from Customer s where s.customerId="+id,Customer.class);
		Customer customer= query.getResultList().get(0);
		Coupons coupons=new Coupons();
		coupons.setCouponNumber(coupon);
		coupons.setDiscount((double)discount);
		Date date=new Date();
		Date expiredate=new Date();
		expiredate.setMonth(date.getMonth());
		coupons.setExpiryDate(expiredate);
		entityManager.persist(coupons);
		customer.setCoupons(coupons);
	}

	@Override
	public List<Inventory> inventoryLowToHigh(String type) {
		TypedQuery<Inventory> query=entityManager.createQuery("Select s from Inventory s where s.inventoryType=:Type order by s.price",Inventory.class);
		query.setParameter("Type", type);
		return query.getResultList();
	}

	@Override
	public List<Inventory> inventoryHighToLow(String type) {
		TypedQuery<Inventory> query=entityManager.createQuery("Select s from Inventory s where s.inventoryType=:Types order by s.price desc",Inventory.class);
		query.setParameter("Types", type);
		return query.getResultList();
	}
}
