package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IQueryDAO;
import com.cg.entities.Coupons;



@Service
@Transactional
public class QueryServiceImpl implements IQueryService {

	@Autowired
	IQueryDAO iQueryDAO;
	
	

	@Override
	public void plp() {
		iQueryDAO.plp();
	}


	@Override
	public List<Coupons> showCoupons(int couponNumber) {
		return iQueryDAO.showCoupons(couponNumber);
	}
	/*@Override
	public Coupons find(int couponNumber) {
		return iQueryDAO.find(couponNumber);
	}
*/
	@Override
	public void find(int couponId) {
		 iQueryDAO.find(couponId);
	}
}
