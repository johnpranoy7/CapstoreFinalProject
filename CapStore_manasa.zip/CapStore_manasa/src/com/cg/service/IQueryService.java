package com.cg.service;

import java.util.List;

import com.cg.entities.Coupons;


public interface IQueryService {

	// List<QueryAnswers> getall();
void plp();
public List<Coupons> showCoupons(int couponNumber);
void find(int i);
}
