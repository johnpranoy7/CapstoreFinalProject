package com.cg.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Coupons;
import com.cg.entities.CustomerCap;

import com.cg.service.IQueryService;

@Controller
public class QueryController {
	
	@Autowired
	IQueryService iQueryService;
	double discount;
	CustomerCap customer;
	/*
	@RequestMapping("/search")
	public String index() {
		
		return "search";
	}*/
	@RequestMapping("/index")
	public String index(Model model) {
		iQueryService.plp();
		/*model.addAttribute("customer", new CustomerCap());
		List<Coupons> list=iQueryService.showCoupons();
		for(Coupons coupons:list)
			System.out.println(coupons);
		model.addAttribute("coupons",list);*/
		return "index";
	}

	
@RequestMapping("/search")
public String search(Model model,@RequestParam("couponNumber")String couponNumber) {
	List<Coupons> query1=iQueryService.showCoupons(Integer.parseInt(couponNumber));
	System.out.println("((((((((((((((((((((((((***********************"+query1);

		if(query1!=null) {
			int coupon;
			for(int i=0;i<query1.size();i++){
				
				int coupon1=query1.get(0).getCouponId();
				System.out.println(coupon1+"AA");
				//iQueryService.find(query1);
				 //discount = coupon1.getDiscount();
			} 
		return "search";
	}
	else {
		model.addAttribute("couponNumber", couponNumber);
		return "error";
	}
	
}
}

