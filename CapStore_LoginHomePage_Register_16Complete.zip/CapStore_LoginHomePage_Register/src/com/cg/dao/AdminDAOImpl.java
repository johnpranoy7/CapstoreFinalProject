package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;

@Repository
public class AdminDAOImpl implements IAdminDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
		public Admin isAdmin(String userName, String userPassword) {
		TypedQuery<Admin> query=entityManager.createQuery("select a from Admin a where a.emailId=:eId and a.password=:pwd",Admin.class);
		query.setParameter("eId",userName);
		query.setParameter("pwd",userPassword);
		List<Admin> users = query.getResultList();
		//System.out.println(users);
		if(users.size()>0)
			return users.get(0);
		else
			return null; 
	}

	@Override
	public String getAdminPassword(String userName) {
		TypedQuery<Admin> query=entityManager.createQuery("select a from Admin a where a.emailId=:eId",Admin.class);
		query.setParameter("eId",userName);
		List<Admin> users = query.getResultList();
		//System.out.println(users);
		if(users.size()>0)
			return users.get(0).getPassword();
		else
			return null; 
	}

	@Override
	public List<Merchant> ViewallMerchant() {
		TypedQuery<Merchant> query2=entityManager.createQuery("Select m from Merchant m",Merchant.class);
		return query2.getResultList();
	}

	@Override
	public List<Inventory> ViewallInventory() {
		TypedQuery<Inventory> query1=entityManager.createQuery("Select i from Inventory i",Inventory.class);
		return query1.getResultList();
	}

	@Override
	public List<Customer> ViewallCustomer() {
		TypedQuery<Customer> query=entityManager.createQuery("select c from Customer c",Customer.class);
		return query.getResultList();
	}

	@Override
	public boolean removeMerchant(int merchant) {
		TypedQuery<Inventory> query=entityManager.createQuery("Select i from Inventory i where i.merchant.merchantId=:id",Inventory.class);
		query.setParameter("id", merchant);
		List<Inventory> allInventories=query.getResultList();
		for (Inventory inventory : allInventories) {
			System.out.println(inventory);
			entityManager.remove(inventory);
		}
	  Merchant merchantFound = entityManager.find(Merchant.class, merchant);
	  System.out.println("Merchant found"+merchantFound);
	  if(merchantFound!=null)
	  {
	   entityManager.remove(merchantFound);
	   return true;
	  }else {
	  return false;
	 }
	}

	@Override
	public boolean removeInventory(int inventory) {
		Inventory inventoryFound = entityManager.find(Inventory.class, inventory);
		System.out.println("Inventory found"+inventoryFound);
		if(inventoryFound!=null)
		{
			entityManager.remove(inventoryFound);
		
			return true;
		}else {
		return false;
	}
	}

}
